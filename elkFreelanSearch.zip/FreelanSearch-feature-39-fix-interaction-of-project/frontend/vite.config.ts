import { defineConfig } from 'vite'
import path from 'path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

function figmaAssetResolver() {
  return {
    name: 'figma-asset-resolver',
    // Добавили явную типизацию : string для параметра id
    resolveId(id: string) {
      if (id.startsWith('figma:asset/')) {
        const filename = id.replace('figma:asset/', '')
        return path.resolve(__dirname, 'src/assets', filename)
      }
    },
  }
}

export default defineConfig({
  plugins: [
    figmaAssetResolver(),
    // The React and Tailwind plugins are both required for Make, even if
    // Tailwind is not being actively used – do not remove them
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      // Alias @ to the src directory
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5173, // Явно фиксируем порт для докера
    strictPort: true,
    watch: {
      usePolling: true, // Добавлено для стабильного Hot Reload внутри Docker-контейнера
    },
    proxy: {
      '/api/': {
        // Если запускаешь через docker-compose, вместо localhost:8000 
        // можно будет указать имя сервиса бэкенда, например http://profile-service:8080
        target: process.env.VITE_BACKEND_PROXY_TARGET ?? 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },

  // File types to support raw imports. Never add .css, .tsx, or .ts files to this.
  assetsInclude: ['**/*.svg', '**/*.csv'],
})